# TaskPilot Google Calendar setup

1. Back up your current project, especially `.env`, `data/`, and `src/`.
2. Copy this update into the project folder. Keep your existing `.env` and `data/`.
3. In Google Cloud Console create a project, enable **Google Calendar API**, configure the OAuth consent screen, and create an **OAuth client ID → Web application**.
4. Add authorized redirect URI `http://localhost:3000/api/calendar/callback` (must exactly match `GOOGLE_REDIRECT_URI`). If the OAuth app is in testing, add your Google email as a test user.
5. Copy `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` into `.env`. Set `GOOGLE_REDIRECT_URI` and generate a persistent `CALENDAR_ENCRYPTION_KEY` (64 hexadecimal characters) with `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`. Do not rotate this key without migrating encrypted connections.
6. Run `npm install`, then `npm start`. Sign into TaskPilot → Mission Control → Connect Google Calendar → approve Google permissions.
7. Enter event title, start/end, timezone, review the confirmation, and create the event. Google must confirm before success is shown.

## Security and limitations
- OAuth uses a state token tied to the signed-in TaskPilot account and PKCE. OAuth credentials and encrypted refresh tokens remain server-side; never put secrets in public JS.
- Calendar scope is limited to `calendar.events`. Disconnect removes the local stored token; revoke access from Google Account settings to revoke it at Google.
- This is **manual, user-approved event creation**. AI parsing, automatic mission-to-event mapping, task completion updates, and scheduled/background automation are **not implemented** in this phase.
- `calendar-connections.json` lives under `data/` and is excluded by `.gitignore`. Do not publish your existing `data/` or `.env` files. Existing uploaded ZIP contains user data; this distribution intentionally omits it.
- Existing in-memory sessions and OAuth states do not survive a server restart. The server is currently bound to `127.0.0.1`, suitable for local development. Before Render deployment, use persistent encrypted storage, a persistent session store, HTTPS-aware cookies, correct proxy settings, and a production redirect URI. Render's ephemeral filesystem is unsuitable for storing tokens or task data without an external database.
