TaskPilot Cosmos-inspired login/signup redesign

Updated: public/login.html and added public/css/auth-cosmos.css.
Authentication logic and all dashboard/mission files remain unchanged.
Copy files into existing project, keep data/, src/, .env. Restart npm start and hard refresh.
The design is an original Cosmos-inspired editorial treatment, not an exact reproduction of a reference screenshot.
