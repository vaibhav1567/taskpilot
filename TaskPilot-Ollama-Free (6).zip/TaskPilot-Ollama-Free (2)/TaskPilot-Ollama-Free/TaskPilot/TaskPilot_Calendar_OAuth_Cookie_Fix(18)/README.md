# TaskPilot Google Calendar OAuth callback fix

## Install
1. Stop TaskPilot (`Ctrl+C`).
2. Replace the **root** `auth.js` file (beside `server.js`) with this updated `auth.js`. Do not place it in `public/`.
3. Keep your existing `.env`, `data/`, `calendar.js`, `src/`, and other files unchanged.
4. Run `npm start`. Log in to TaskPilot and click Connect Google Calendar again. Start a new authorization flow; do not reuse the old callback URL.

## Root cause
The session cookie was `SameSite=Strict`. On a top-level cross-site redirect from Google, the browser does not send that cookie, so `currentUser(req)` returned null and the callback reported authorization expired. `SameSite=Lax` permits the cookie on the top-level GET callback.

## Notes
The existing same-origin check for POST/PUT/PATCH/DELETE remains unchanged. A separate server restart during authorization can still invalidate in-memory OAuth state; finish the flow without restarting. For public production deployment, use HTTPS and secure cookies, persistent sessions/state, and additional CSRF/security hardening.
