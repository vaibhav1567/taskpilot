TaskPilot — Normal Modern Theme

Visual-only change: replaced minimalist overrides with modern light-blue dashboard and login styling. All application JavaScript, server, task store and authentication logic are unchanged.

Installation: copy files into existing TaskPilot folder. Keep existing .env, src and data folders. Run npm start and hard-refresh the browser.
