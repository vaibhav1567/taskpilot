TaskPilot rotating mission suggestions

- Shows three randomized mission ideas on every login/signup redirect to Mission Control.
- Suggestions rotate every 15 seconds while Mission Control is visible, or immediately with More ideas.
- Clicking a suggestion fills the objective field, but automatic rotation never overwrites user input.
- Suggestions are a curated list, not AI-generated or personalized.
- Authentication, mission storage, and task features are unchanged.

Installation: Merge the contents of TaskPilot_Normal_Theme into your existing project. Keep your .env, src and data folders. Run npm start and hard-refresh your browser.
