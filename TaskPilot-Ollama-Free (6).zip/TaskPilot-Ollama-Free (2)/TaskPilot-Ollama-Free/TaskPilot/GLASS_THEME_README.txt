TaskPilot Cosmos + Liquid Glass Theme

Changes are CSS-only plus two new stylesheet references in public/index.html and public/login.html.
- public/css/liquid-glass.css : dashboard, navigation, mission cards, controls
- public/css/auth-glass.css : login and sign-up

Install: copy extracted files over your existing project. Keep your .env, src, and data folders intact. Run npm start and hard-refresh the browser (Ctrl+Shift+R).

Appearance is inspired by translucent iOS-style glass, not an exact Apple interface reproduction. CSS supports reduced transparency and reduced motion preferences.
